package com.example.mycontacts.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPreferenceHelper {
    private String PREFS_FILE_NAME = "MyContacts";
    private String PREFS_KEY_USER_ID = "userId";
    private String PREFS_KEY_PASSWORD = "password";
    private String PREFS_KEY_IS_LOGGED_IN = "isLoggedIn";

    public String getUserId(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFS_FILE_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getString(PREFS_KEY_USER_ID, "");
    }

    public void setUserId(Context context, String userId) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFS_FILE_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(PREFS_KEY_USER_ID, userId);
        editor.apply();
    }

    public String getPassword(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFS_FILE_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getString(PREFS_KEY_PASSWORD, "");
    }

    public void setPassword(Context context, String password) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFS_FILE_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(PREFS_KEY_PASSWORD, password);
        editor.apply();
    }

    public boolean isLoggedIn(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFS_FILE_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getBoolean(PREFS_KEY_IS_LOGGED_IN, false);
    }

    public void setLoggedIn(Context context, boolean loggedIn) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFS_FILE_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(PREFS_KEY_IS_LOGGED_IN, loggedIn);
        editor.apply();
    }
}
