package com.example.mycontacts.utils;

public class Constants {
    public static final String KEY_BROADCAST = "com.example.mycontacts.CUSTOM_BROADCAST";
    public static final String KEY_LOCAL_BROADCAST = "com.example.mycontacts.LOCAL_BROADCAST";
}
