package com.example.mycontacts.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import com.example.mycontacts.utils.Constants;

public class MyReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if(intent.getAction().equals(Constants.KEY_BROADCAST)){
            Toast.makeText(context, "Broadcast received", Toast.LENGTH_LONG).show();
        }
        else if(intent.getAction().equals(Constants.KEY_LOCAL_BROADCAST)){
            Toast.makeText(context, "Local broadcast received", Toast.LENGTH_LONG).show();
        }
    }
}
