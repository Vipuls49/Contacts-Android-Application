package com.example.mycontacts.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.mycontacts.R;

public class TermsFragment extends Fragment {
    private WebView wvTerms;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_terms_conditions, null);

        initViews(view);
        loadData();

        return view;
    }

    private void initViews(View view){
        wvTerms = view.findViewById(R.id.fragment_terms_wv);
    }

    private void loadData(){
        wvTerms.loadUrl("https://www.google.com");
    }
}
