package com.example.mycontacts.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.mycontacts.R;
import com.example.mycontacts.utils.SharedPreferenceHelper;

public class LoginFragment extends Fragment implements View.OnClickListener {
    private EditText etUserId;
    private EditText etPassword;
    private Button btnLogin;
    private TextView tvRegister;
    private SharedPreferenceHelper preferenceHelper;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_login, null);

        initViews(view);
        initListeners();
        populateData();

        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.fragment_login_btn_login:
                preferenceHelper.setUserId(getActivity(), etUserId.getText().toString().trim());
                preferenceHelper.setPassword(getActivity(), etPassword.getText().toString().trim());
                preferenceHelper.setLoggedIn(getActivity(), true);

                ContactListFragment contactListFragment = new ContactListFragment();

                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.main_fl_container, contactListFragment, contactListFragment.getTag());
                fragmentTransaction.commit();
                break;

            case R.id.fragment_login_tv_disclaimer:
                RegistrationFragment registrationFragment = new RegistrationFragment();

                FragmentManager fragmentManager1 = getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction1 = fragmentManager1.beginTransaction();
                fragmentTransaction1.replace(R.id.main_fl_container, registrationFragment, registrationFragment.getTag());
                fragmentTransaction1.commit();
                break;
        }
    }

    private void initViews(View view){
        etUserId = view.findViewById(R.id.fragment_login_et_user_id);
        etPassword = view.findViewById(R.id.fragment_login_et_password);
        btnLogin = view.findViewById(R.id.fragment_login_btn_login);
        tvRegister = view.findViewById(R.id.fragment_login_tv_disclaimer);
    }

    private void initListeners(){
        btnLogin.setOnClickListener(this);
        tvRegister.setOnClickListener(this);
    }

    private void populateData(){
        preferenceHelper = new SharedPreferenceHelper();
        String userId = preferenceHelper.getUserId(getActivity());

        if(userId != null && !userId.isEmpty()){
            etUserId.setText(userId);
        }
    }
}
