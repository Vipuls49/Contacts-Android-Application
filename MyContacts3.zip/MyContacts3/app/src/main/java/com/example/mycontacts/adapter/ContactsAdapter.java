package com.example.mycontacts.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mycontacts.R;
import com.example.mycontacts.pojo.ContactsPojo;

import java.util.List;

public class ContactsAdapter extends RecyclerView.Adapter<ContactsAdapter.ContactsHolder> {
    private List<ContactsPojo> mListContacts;

    public ContactsAdapter(List<ContactsPojo> listContacts){
        mListContacts = listContacts;
    }

    @NonNull
    @Override
    public ContactsAdapter.ContactsHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_contact_list_item, parent, false);
        return new ContactsHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ContactsAdapter.ContactsHolder holder, int position) {
        ContactsPojo contactsPojo = mListContacts.get(position);

        holder.tvName.setText(contactsPojo.getFirstName() + " " + contactsPojo.getLastName());
        holder.tvNumber.setText(contactsPojo.getContactNumber());
    }

    @Override
    public int getItemCount() {
        return mListContacts.size();
    }

    class ContactsHolder extends RecyclerView.ViewHolder{
        private TextView tvName;
        private TextView tvNumber;

        ContactsHolder(View itemView) {
            super(itemView);

            tvName = itemView.findViewById(R.id.contact_list_item_tv_name);
            tvNumber = itemView.findViewById(R.id.contact_list_item_tv_contact);
        }
    }
}
